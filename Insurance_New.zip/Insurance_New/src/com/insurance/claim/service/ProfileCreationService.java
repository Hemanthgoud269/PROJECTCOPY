package com.insurance.claim.service;

import com.insurance.claim.bean.ProfileCreation;
import com.insurance.claim.dao.ProfileDAO;

public class ProfileCreationService  implements IProfileCreationService 
{

	@Override
	public int addProfile(String user, String pass, String role,String agcode)
	{
		ProfileDAO ProfileDao = new ProfileDAO();
		ProfileCreation probean = new ProfileCreation();
		probean.setUsername(user);
		probean.setPassword(pass);
		probean.setRolecode(role);
		probean.setAgcode(agcode);
		int updateResult = 0;
		 try
		 {
			 updateResult = ProfileDao.addProfile(probean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
		
	}



	
}
